﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// a single icon on a reel
public class ReelIcon : MonoBehaviour 
{
	public Renderer myRenderer;

	public Texture2D[] iconTextures;

	public void SetIcon( int theIconId )
	{
		myRenderer.material.mainTexture = iconTextures[theIconId];
	}
}
