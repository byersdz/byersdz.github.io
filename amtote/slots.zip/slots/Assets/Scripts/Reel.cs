﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// a single reel
public class Reel : MonoBehaviour
{
	public GameObject iconPrefab;
	public State state;
	public float speed = 90;
	public AudioSource myAudio;

	private float currentAngle;


	private float stoppingAngle;

	public enum State
	{
		Stopped,
		Spinning,
		Stopping
	}

	private const int numberOfIconsOnReel = 16; // the reel only supports exactly 16 icons
	private const float degreesPerPosition = 22.5f;
	private const int numberOfIconTypes = 4;


	void Awake()
	{
		GenerateIcons();
	}


    private void GenerateIcons()
    {
		for ( int i = 0; i < numberOfIconsOnReel; i++ )
		{
			GameObject instance = Instantiate( iconPrefab );
			instance.transform.parent = transform;
			instance.transform.localPosition = Vector3.zero;

			// rotate the icon around the reel to the correct position
			instance.transform.localEulerAngles = new Vector3( -( 360.0f / numberOfIconsOnReel ) * i, 180, 0 );

			ReelIcon reelIcon = instance.GetComponent<ReelIcon>();

			// randomly set each icon type 
			// this is really dumb, just a simple way to get this example working
			// no guarantees of there being icons of each type in each reel
			reelIcon.SetIcon( Random.Range( 0, numberOfIconTypes ) );
		}
    }

	void Update()
	{
		if ( state == State.Spinning )
		{
			currentAngle -= speed * Time.deltaTime;

			currentAngle = Mathf.Repeat( currentAngle, 360.0f );

			transform.localEulerAngles = new Vector3( currentAngle, 0, 0 );
		}
		else if ( state == State.Stopping )
		{
			currentAngle = stoppingAngle;
			currentAngle = Mathf.Repeat( currentAngle, 360.0f );
			transform.eulerAngles = new Vector3( currentAngle, 0, 0 );
		}
	}

	public void StartSpin()
	{
		state = State.Spinning;
	}

	public void StopWithDelay( float theDelay )
	{
		Invoke( "StopAtNextPosition", theDelay );
	}

	public void StopAtNextPosition()
	{
		myAudio.Play();

		state = State.Stopping;

		int nextPosition = GetCurrentPosition() - 1;
		if ( nextPosition < 0 )
		{
			nextPosition = numberOfIconsOnReel - 1;
		}
			
		float stoppingStartAngle = currentAngle;
		float stoppingFinishAngle = nextPosition * degreesPerPosition;

		if ( stoppingFinishAngle > stoppingStartAngle )
		{
			stoppingStartAngle += 360;
		}


		float stopTime = Mathf.Abs( stoppingStartAngle - stoppingFinishAngle ) / speed * 8;

		stoppingAngle = currentAngle;

		iTween.Stop( gameObject );

		iTween.ValueTo( gameObject, iTween.Hash( "from", stoppingStartAngle, 
			"to", stoppingFinishAngle, 
			"onupdate", "UpdateStoppingAngle", 
			"easetype", iTween.EaseType.easeOutElastic,
			"time", stopTime ) );
	}

	public void UpdateStoppingAngle( float theAngle )
	{
		stoppingAngle = theAngle;
	}

	public int GetCurrentPosition()
	{
		if ( currentAngle >= 360.0f - ( degreesPerPosition / 2 ) || currentAngle <= degreesPerPosition / 2 )
		{
			// this is the first position
			return 0;
		}

		float adjustedAngle = currentAngle + ( degreesPerPosition / 2 );
		return Mathf.FloorToInt( adjustedAngle / degreesPerPosition );
	}

}
