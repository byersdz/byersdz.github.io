﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// creates the reels and tells them when to begin and end spinning
public class ReelManager : MonoBehaviour 
{
	public GameObject reelPrefab;
	public int numberOfReels = 3;
	public State state;
	public AudioSource myAudio;

	public enum State
	{
		WaitingForInput,
		Spinning,
		ShowingResults
	}

	private List<Reel> reels;

	// Use this for initialization
	void Awake () 
	{
		BuildReels();
	}

	void Update()
	{
		if ( Input.GetKeyDown( KeyCode.Escape ) )
		{
			Application.Quit();
		}
	}

	private void BuildReels()
	{
		reels = new List<Reel>();

		for ( int i = 0; i < numberOfReels; i++ )
		{
			GameObject instance = Instantiate( reelPrefab );

			float spacing = 0.6f;
			float xPosition = ( i * spacing ) - ( ( numberOfReels - 1 ) * spacing / 2 );

			instance.transform.position = new Vector3( xPosition, 0, 0 );

			Reel reel = instance.GetComponent<Reel>();
			reels.Add( reel );
		}
	}

	public void StartPressed()
	{
		if ( state == State.WaitingForInput )
		{
			StartSpin();
		}
	}

	private void StartSpin()
	{
		state = State.Spinning;

		foreach ( Reel reel in reels )
		{
			reel.speed = Random.Range( 180.0f, 270.0f );
			reel.StartSpin();
		}

		myAudio.Play();
	}

	public void StopPressed()
	{
		if ( state == State.Spinning )
		{
			EndSpin();
		}
	}

	private void EndSpin()
	{
		state = State.ShowingResults;

		int count = 0;
		foreach ( Reel reel in reels )
		{
			reel.StopWithDelay( count * 0.25f );
			count++;
		}

		Invoke( "FinishedShowingResults", 2 );
	}

	private void FinishedShowingResults()
	{
		state = State.WaitingForInput;
	}
}
